from flask_sqlalchemy import SQLAlchemy
from datetime import datetime

db = SQLAlchemy()

class Product(db.Model):
    """نموذج المنتجات في المستودع"""
    __tablename__ = 'products'
    
    product_id = db.Column(db.Integer, primary_key=True)
    type = db.Column(db.String(100), nullable=False)  # نوع المنتج
    size = db.Column(db.String(50), nullable=True)    # مقاس المنتج
    brand = db.Column(db.String(100), nullable=True)  # ماركة المنتج
    current_quantity = db.Column(db.Integer, default=0)  # الكمية الحالية
    import_price = db.Column(db.Float, nullable=True)    # سعر الاستيراد
    selling_price = db.Column(db.Float, nullable=True)   # سعر البيع
    
    # العلاقات
    incoming_items = db.relationship('IncomingItem', backref='product', lazy=True)
    outgoing_items = db.relationship('OutgoingItem', backref='product', lazy=True)
    
    def __repr__(self):
        return f'<Product {self.type} - {self.brand}>'
    
    @property
    def profit_per_unit(self):
        """حساب الربح لكل وحدة"""
        if self.selling_price and self.import_price:
            return self.selling_price - self.import_price
        return 0
    
    @property
    def total_incoming(self):
        """إجمالي الكميات الواردة"""
        return sum(item.quantity for item in self.incoming_items)
    
    @property
    def total_outgoing(self):
        """إجمالي الكميات الصادرة"""
        return sum(item.quantity for item in self.outgoing_items)
    
    def to_dict(self):
        return {
            'product_id': self.product_id,
            'type': self.type,
            'size': self.size,
            'brand': self.brand,
            'current_quantity': self.current_quantity,
            'import_price': self.import_price,
            'selling_price': self.selling_price,
            'profit_per_unit': self.profit_per_unit,
            'total_incoming': self.total_incoming,
            'total_outgoing': self.total_outgoing
        }


class IncomingItem(db.Model):
    """نموذج الواردات"""
    __tablename__ = 'incoming_items'
    
    incoming_id = db.Column(db.Integer, primary_key=True)
    product_id = db.Column(db.Integer, db.ForeignKey('products.product_id'), nullable=False)
    supplier_name = db.Column(db.String(200), nullable=False)  # اسم المورد
    quantity = db.Column(db.Integer, nullable=False)           # الكمية الواردة
    price = db.Column(db.Float, nullable=False)                # السعر الإجمالي
    date = db.Column(db.Date, nullable=False, default=datetime.utcnow)  # تاريخ الوارد
    notes = db.Column(db.Text, nullable=True)                  # ملاحظات
    
    def __repr__(self):
        return f'<IncomingItem {self.supplier_name} - {self.quantity}>'
    
    @property
    def unit_price(self):
        """سعر الوحدة الواحدة"""
        if self.quantity > 0:
            return self.price / self.quantity
        return 0
    
    def to_dict(self):
        return {
            'incoming_id': self.incoming_id,
            'product_id': self.product_id,
            'supplier_name': self.supplier_name,
            'quantity': self.quantity,
            'price': self.price,
            'unit_price': self.unit_price,
            'date': self.date.isoformat() if self.date else None,
            'notes': self.notes,
            'product': self.product.to_dict() if self.product else None
        }


class OutgoingItem(db.Model):
    """نموذج الصادرات"""
    __tablename__ = 'outgoing_items'
    
    outgoing_id = db.Column(db.Integer, primary_key=True)
    product_id = db.Column(db.Integer, db.ForeignKey('products.product_id'), nullable=False)
    customer_name = db.Column(db.String(200), nullable=False)  # اسم المشتري
    quantity = db.Column(db.Integer, nullable=False)           # الكمية الصادرة
    price = db.Column(db.Float, nullable=False)                # السعر الإجمالي
    date = db.Column(db.Date, nullable=False, default=datetime.utcnow)  # تاريخ الصادر
    notes = db.Column(db.Text, nullable=True)                  # ملاحظات
    
    def __repr__(self):
        return f'<OutgoingItem {self.customer_name} - {self.quantity}>'
    
    @property
    def unit_price(self):
        """سعر الوحدة الواحدة"""
        if self.quantity > 0:
            return self.price / self.quantity
        return 0
    
    @property
    def total_profit(self):
        """إجمالي الربح من هذه العملية"""
        if self.product and self.product.import_price:
            return (self.unit_price - self.product.import_price) * self.quantity
        return 0
    
    def to_dict(self):
        return {
            'outgoing_id': self.outgoing_id,
            'product_id': self.product_id,
            'customer_name': self.customer_name,
            'quantity': self.quantity,
            'price': self.price,
            'unit_price': self.unit_price,
            'total_profit': self.total_profit,
            'date': self.date.isoformat() if self.date else None,
            'notes': self.notes,
            'product': self.product.to_dict() if self.product else None
        }

