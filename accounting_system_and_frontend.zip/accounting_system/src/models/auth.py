from src.models.accounting import db
from werkzeug.security import generate_password_hash, check_password_hash
from datetime import datetime, timedelta
import jwt
import os

class User(db.Model):
    """نموذج المستخدمين"""
    __tablename__ = 'users'
    
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(80), unique=True, nullable=False)
    email = db.Column(db.String(120), unique=True, nullable=False)
    password_hash = db.Column(db.String(255), nullable=False)
    full_name = db.Column(db.String(200), nullable=False)
    role_id = db.Column(db.Integer, db.ForeignKey('roles.id'), nullable=False)
    is_active = db.Column(db.Boolean, default=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    last_login = db.Column(db.DateTime)
    
    # العلاقات
    role = db.relationship('Role', backref='users', lazy=True)
    
    def __repr__(self):
        return f'<User {self.username}>'
    
    def set_password(self, password):
        """تشفير كلمة المرور"""
        self.password_hash = generate_password_hash(password)
    
    def check_password(self, password):
        """التحقق من كلمة المرور"""
        return check_password_hash(self.password_hash, password)
    
    def generate_token(self):
        """إنشاء JWT token"""
        payload = {
            'user_id': self.id,
            'username': self.username,
            'role': self.role.name,
            'exp': datetime.utcnow() + timedelta(hours=24)
        }
        return jwt.encode(payload, os.environ.get('SECRET_KEY', 'default-secret'), algorithm='HS256')
    
    @staticmethod
    def verify_token(token):
        """التحقق من صحة JWT token"""
        try:
            payload = jwt.decode(token, os.environ.get('SECRET_KEY', 'default-secret'), algorithms=['HS256'])
            return User.query.get(payload['user_id'])
        except jwt.ExpiredSignatureError:
            return None
        except jwt.InvalidTokenError:
            return None
    
    def has_permission(self, permission_name):
        """التحقق من وجود صلاحية معينة"""
        return any(perm.name == permission_name for perm in self.role.permissions)
    
    def to_dict(self):
        return {
            'id': self.id,
            'username': self.username,
            'email': self.email,
            'full_name': self.full_name,
            'role': self.role.name if self.role else None,
            'is_active': self.is_active,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'last_login': self.last_login.isoformat() if self.last_login else None,
            'permissions': [perm.name for perm in self.role.permissions] if self.role else []
        }


class Role(db.Model):
    """نموذج الأدوار"""
    __tablename__ = 'roles'
    
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(80), unique=True, nullable=False)
    description = db.Column(db.String(255))
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    def __repr__(self):
        return f'<Role {self.name}>'
    
    def to_dict(self):
        return {
            'id': self.id,
            'name': self.name,
            'description': self.description,
            'permissions': [perm.name for perm in self.permissions]
        }


class Permission(db.Model):
    """نموذج الصلاحيات"""
    __tablename__ = 'permissions'
    
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(80), unique=True, nullable=False)
    description = db.Column(db.String(255))
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    def __repr__(self):
        return f'<Permission {self.name}>'
    
    def to_dict(self):
        return {
            'id': self.id,
            'name': self.name,
            'description': self.description
        }


# جدول الربط بين الأدوار والصلاحيات
role_permissions = db.Table('role_permissions',
    db.Column('role_id', db.Integer, db.ForeignKey('roles.id'), primary_key=True),
    db.Column('permission_id', db.Integer, db.ForeignKey('permissions.id'), primary_key=True)
)

# إضافة العلاقة many-to-many
Role.permissions = db.relationship('Permission', secondary=role_permissions, lazy='subquery',
                                 backref=db.backref('roles', lazy=True))


def init_default_data():
    """إنشاء البيانات الافتراضية للأدوار والصلاحيات"""
    
    # إنشاء الصلاحيات الافتراضية
    permissions_data = [
        ('view_dashboard', 'عرض لوحة التحكم'),
        ('manage_products', 'إدارة المنتجات'),
        ('view_products', 'عرض المنتجات'),
        ('add_products', 'إضافة منتجات'),
        ('edit_products', 'تعديل منتجات'),
        ('delete_products', 'حذف منتجات'),
        ('manage_incoming', 'إدارة الواردات'),
        ('view_incoming', 'عرض الواردات'),
        ('add_incoming', 'إضافة واردات'),
        ('edit_incoming', 'تعديل واردات'),
        ('delete_incoming', 'حذف واردات'),
        ('manage_outgoing', 'إدارة الصادرات'),
        ('view_outgoing', 'عرض الصادرات'),
        ('add_outgoing', 'إضافة صادرات'),
        ('edit_outgoing', 'تعديل صادرات'),
        ('delete_outgoing', 'حذف صادرات'),
        ('view_reports', 'عرض التقارير'),
        ('export_reports', 'تصدير التقارير'),
        ('view_financial_reports', 'عرض التقارير المالية'),
        ('manage_users', 'إدارة المستخدمين'),
        ('add_users', 'إضافة مستخدمين'),
        ('edit_users', 'تعديل مستخدمين'),
        ('delete_users', 'حذف مستخدمين'),
        ('manage_roles', 'إدارة الأدوار'),
        ('assign_permissions', 'تعيين الصلاحيات'),
        ('system_admin', 'إدارة النظام'),
        ('backup_data', 'نسخ احتياطي للبيانات'),
        ('restore_data', 'استعادة البيانات'),
        ('view_audit_logs', 'عرض سجلات المراجعة')
    ]
    
    for perm_name, perm_desc in permissions_data:
        if not Permission.query.filter_by(name=perm_name).first():
            permission = Permission(name=perm_name, description=perm_desc)
            db.session.add(permission)
    
    db.session.commit()
    
    # إنشاء الأدوار الافتراضية
    roles_data = [
        ('owner', 'المالك', [
            'view_dashboard', 'manage_products', 'view_products', 'add_products', 'edit_products', 'delete_products',
            'manage_incoming', 'view_incoming', 'add_incoming', 'edit_incoming', 'delete_incoming',
            'manage_outgoing', 'view_outgoing', 'add_outgoing', 'edit_outgoing', 'delete_outgoing',
            'view_reports', 'export_reports', 'view_financial_reports',
            'manage_users', 'add_users', 'edit_users', 'delete_users',
            'manage_roles', 'assign_permissions', 'system_admin',
            'backup_data', 'restore_data', 'view_audit_logs'
        ]),
        ('manager', 'مدير', [
            'view_dashboard', 'manage_products', 'view_products', 'add_products', 'edit_products',
            'manage_incoming', 'view_incoming', 'add_incoming', 'edit_incoming',
            'manage_outgoing', 'view_outgoing', 'add_outgoing', 'edit_outgoing',
            'view_reports', 'export_reports', 'view_financial_reports'
        ]),
        ('financial', 'مالي', [
            'view_dashboard', 'view_products',
            'view_incoming', 'view_outgoing',
            'view_reports', 'export_reports', 'view_financial_reports'
        ]),
        ('data_entry', 'مدخل بيانات', [
            'view_dashboard', 'view_products', 'add_products', 'edit_products',
            'add_incoming', 'edit_incoming', 'view_incoming',
            'add_outgoing', 'edit_outgoing', 'view_outgoing'
        ])
    ]
    
    for role_name, role_desc, role_permissions in roles_data:
        if not Role.query.filter_by(name=role_name).first():
            role = Role(name=role_name, description=role_desc)
            
            # إضافة الصلاحيات للدور
            for perm_name in role_permissions:
                permission = Permission.query.filter_by(name=perm_name).first()
                if permission:
                    role.permissions.append(permission)
            
            db.session.add(role)
    
    db.session.commit()
    
    # إنشاء مستخدم افتراضي (المالك)
    if not User.query.filter_by(username='admin').first():
        owner_role = Role.query.filter_by(name='owner').first()
        owner_user = User(
            username='admin',
            email='admin@example.com',
            full_name='المالك',
            role_id=owner_role.id
        )
        owner_user.set_password('admin123')
        db.session.add(owner_user)
        db.session.commit()

