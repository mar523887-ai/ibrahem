from flask import Blueprint, request, jsonify
from src.models.accounting import db, Product, IncomingItem, OutgoingItem
from datetime import datetime, timedelta
from sqlalchemy import func

reports_bp = Blueprint('reports', __name__)

@reports_bp.route('/reports/inventory', methods=['GET'])
def inventory_report():
    """تقرير المخزون الحالي"""
    try:
        products = Product.query.all()
        
        total_value = 0
        low_stock_count = 0
        threshold = request.args.get('threshold', 10, type=int)
        
        inventory_data = []
        for product in products:
            product_value = product.current_quantity * (product.import_price or 0)
            total_value += product_value
            
            if product.current_quantity <= threshold:
                low_stock_count += 1
            
            inventory_data.append({
                'product_id': product.product_id,
                'type': product.type,
                'brand': product.brand,
                'size': product.size,
                'current_quantity': product.current_quantity,
                'import_price': product.import_price,
                'selling_price': product.selling_price,
                'total_value': product_value,
                'is_low_stock': product.current_quantity <= threshold
            })
        
        return jsonify({
            'inventory': inventory_data,
            'summary': {
                'total_products': len(products),
                'total_value': total_value,
                'low_stock_count': low_stock_count,
                'threshold': threshold
            }
        }), 200
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@reports_bp.route('/reports/sales', methods=['GET'])
def sales_report():
    """تقرير المبيعات"""
    try:
        start_date = request.args.get('start_date')
        end_date = request.args.get('end_date')
        
        # إذا لم يتم تحديد التواريخ، استخدم آخر 30 يوم
        if not start_date or not end_date:
            end = datetime.utcnow().date()
            start = end - timedelta(days=30)
        else:
            try:
                start = datetime.strptime(start_date, '%Y-%m-%d').date()
                end = datetime.strptime(end_date, '%Y-%m-%d').date()
            except ValueError:
                return jsonify({'error': 'تنسيق التاريخ غير صحيح. استخدم YYYY-MM-DD'}), 400
        
        # الحصول على الصادرات في الفترة المحددة
        outgoing_items = OutgoingItem.query.filter(
            OutgoingItem.date >= start,
            OutgoingItem.date <= end
        ).all()
        
        total_sales = sum(item.price for item in outgoing_items)
        total_profit = sum(item.total_profit for item in outgoing_items)
        total_quantity = sum(item.quantity for item in outgoing_items)
        
        # تجميع المبيعات حسب المنتج
        product_sales = {}
        for item in outgoing_items:
            product_key = f"{item.product.type} - {item.product.brand}"
            if product_key not in product_sales:
                product_sales[product_key] = {
                    'product_type': item.product.type,
                    'product_brand': item.product.brand,
                    'total_quantity': 0,
                    'total_sales': 0,
                    'total_profit': 0
                }
            
            product_sales[product_key]['total_quantity'] += item.quantity
            product_sales[product_key]['total_sales'] += item.price
            product_sales[product_key]['total_profit'] += item.total_profit
        
        # تجميع المبيعات حسب العميل
        customer_sales = {}
        for item in outgoing_items:
            if item.customer_name not in customer_sales:
                customer_sales[item.customer_name] = {
                    'customer_name': item.customer_name,
                    'total_quantity': 0,
                    'total_sales': 0,
                    'total_profit': 0,
                    'transactions_count': 0
                }
            
            customer_sales[item.customer_name]['total_quantity'] += item.quantity
            customer_sales[item.customer_name]['total_sales'] += item.price
            customer_sales[item.customer_name]['total_profit'] += item.total_profit
            customer_sales[item.customer_name]['transactions_count'] += 1
        
        return jsonify({
            'period': {
                'start_date': start.isoformat(),
                'end_date': end.isoformat()
            },
            'summary': {
                'total_sales': total_sales,
                'total_profit': total_profit,
                'total_quantity': total_quantity,
                'transactions_count': len(outgoing_items),
                'average_transaction_value': total_sales / len(outgoing_items) if outgoing_items else 0
            },
            'by_product': list(product_sales.values()),
            'by_customer': list(customer_sales.values())
        }), 200
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@reports_bp.route('/reports/purchases', methods=['GET'])
def purchases_report():
    """تقرير المشتريات"""
    try:
        start_date = request.args.get('start_date')
        end_date = request.args.get('end_date')
        
        # إذا لم يتم تحديد التواريخ، استخدم آخر 30 يوم
        if not start_date or not end_date:
            end = datetime.utcnow().date()
            start = end - timedelta(days=30)
        else:
            try:
                start = datetime.strptime(start_date, '%Y-%m-%d').date()
                end = datetime.strptime(end_date, '%Y-%m-%d').date()
            except ValueError:
                return jsonify({'error': 'تنسيق التاريخ غير صحيح. استخدم YYYY-MM-DD'}), 400
        
        # الحصول على الواردات في الفترة المحددة
        incoming_items = IncomingItem.query.filter(
            IncomingItem.date >= start,
            IncomingItem.date <= end
        ).all()
        
        total_purchases = sum(item.price for item in incoming_items)
        total_quantity = sum(item.quantity for item in incoming_items)
        
        # تجميع المشتريات حسب المورد
        supplier_purchases = {}
        for item in incoming_items:
            if item.supplier_name not in supplier_purchases:
                supplier_purchases[item.supplier_name] = {
                    'supplier_name': item.supplier_name,
                    'total_quantity': 0,
                    'total_purchases': 0,
                    'transactions_count': 0
                }
            
            supplier_purchases[item.supplier_name]['total_quantity'] += item.quantity
            supplier_purchases[item.supplier_name]['total_purchases'] += item.price
            supplier_purchases[item.supplier_name]['transactions_count'] += 1
        
        # تجميع المشتريات حسب المنتج
        product_purchases = {}
        for item in incoming_items:
            product_key = f"{item.product.type} - {item.product.brand}"
            if product_key not in product_purchases:
                product_purchases[product_key] = {
                    'product_type': item.product.type,
                    'product_brand': item.product.brand,
                    'total_quantity': 0,
                    'total_purchases': 0
                }
            
            product_purchases[product_key]['total_quantity'] += item.quantity
            product_purchases[product_key]['total_purchases'] += item.price
        
        return jsonify({
            'period': {
                'start_date': start.isoformat(),
                'end_date': end.isoformat()
            },
            'summary': {
                'total_purchases': total_purchases,
                'total_quantity': total_quantity,
                'transactions_count': len(incoming_items),
                'average_transaction_value': total_purchases / len(incoming_items) if incoming_items else 0
            },
            'by_supplier': list(supplier_purchases.values()),
            'by_product': list(product_purchases.values())
        }), 200
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@reports_bp.route('/reports/profit-loss', methods=['GET'])
def profit_loss_report():
    """تقرير الأرباح والخسائر"""
    try:
        start_date = request.args.get('start_date')
        end_date = request.args.get('end_date')
        
        # إذا لم يتم تحديد التواريخ، استخدم آخر 30 يوم
        if not start_date or not end_date:
            end = datetime.utcnow().date()
            start = end - timedelta(days=30)
        else:
            try:
                start = datetime.strptime(start_date, '%Y-%m-%d').date()
                end = datetime.strptime(end_date, '%Y-%m-%d').date()
            except ValueError:
                return jsonify({'error': 'تنسيق التاريخ غير صحيح. استخدم YYYY-MM-DD'}), 400
        
        # الحصول على المبيعات والمشتريات في الفترة المحددة
        outgoing_items = OutgoingItem.query.filter(
            OutgoingItem.date >= start,
            OutgoingItem.date <= end
        ).all()
        
        incoming_items = IncomingItem.query.filter(
            IncomingItem.date >= start,
            IncomingItem.date <= end
        ).all()
        
        total_revenue = sum(item.price for item in outgoing_items)
        total_cost = sum(item.price for item in incoming_items)
        total_profit = sum(item.total_profit for item in outgoing_items)
        
        return jsonify({
            'period': {
                'start_date': start.isoformat(),
                'end_date': end.isoformat()
            },
            'revenue': total_revenue,
            'cost_of_goods': total_cost,
            'gross_profit': total_profit,
            'profit_margin': (total_profit / total_revenue * 100) if total_revenue > 0 else 0,
            'transactions': {
                'sales_count': len(outgoing_items),
                'purchases_count': len(incoming_items)
            }
        }), 200
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@reports_bp.route('/reports/dashboard', methods=['GET'])
def dashboard_summary():
    """ملخص لوحة التحكم"""
    try:
        # إحصائيات عامة
        total_products = Product.query.count()
        low_stock_products = Product.query.filter(Product.current_quantity <= 10).count()
        
        # إحصائيات اليوم
        today = datetime.utcnow().date()
        today_sales = OutgoingItem.query.filter(OutgoingItem.date == today).all()
        today_purchases = IncomingItem.query.filter(IncomingItem.date == today).all()
        
        today_revenue = sum(item.price for item in today_sales)
        today_cost = sum(item.price for item in today_purchases)
        today_profit = sum(item.total_profit for item in today_sales)
        
        # إحصائيات الشهر الحالي
        month_start = today.replace(day=1)
        month_sales = OutgoingItem.query.filter(OutgoingItem.date >= month_start).all()
        month_purchases = IncomingItem.query.filter(IncomingItem.date >= month_start).all()
        
        month_revenue = sum(item.price for item in month_sales)
        month_cost = sum(item.price for item in month_purchases)
        month_profit = sum(item.total_profit for item in month_sales)
        
        # أفضل المنتجات مبيعاً هذا الشهر
        product_sales = {}
        for item in month_sales:
            product_key = item.product_id
            if product_key not in product_sales:
                product_sales[product_key] = {
                    'product': item.product.to_dict(),
                    'total_quantity': 0,
                    'total_sales': 0
                }
            product_sales[product_key]['total_quantity'] += item.quantity
            product_sales[product_key]['total_sales'] += item.price
        
        top_products = sorted(product_sales.values(), key=lambda x: x['total_sales'], reverse=True)[:5]
        
        return jsonify({
            'inventory': {
                'total_products': total_products,
                'low_stock_products': low_stock_products
            },
            'today': {
                'revenue': today_revenue,
                'cost': today_cost,
                'profit': today_profit,
                'sales_count': len(today_sales),
                'purchases_count': len(today_purchases)
            },
            'this_month': {
                'revenue': month_revenue,
                'cost': month_cost,
                'profit': month_profit,
                'sales_count': len(month_sales),
                'purchases_count': len(month_purchases)
            },
            'top_products': top_products
        }), 200
    except Exception as e:
        return jsonify({'error': str(e)}), 500

