from flask import Blueprint, request, jsonify
from src.models.auth import User, Role, Permission, db
from functools import wraps
import jwt
import os

users_bp = Blueprint('users', __name__)

def token_required(f):
    """ديكوريتر للتحقق من وجود token صحيح"""
    @wraps(f)
    def decorated(*args, **kwargs):
        token = request.headers.get('Authorization')
        if not token:
            return jsonify({'message': 'Token مفقود'}), 401
        
        try:
            if token.startswith('Bearer '):
                token = token[7:]
            data = jwt.decode(token, os.environ.get('SECRET_KEY', 'default-secret'), algorithms=['HS256'])
            current_user = User.query.get(data['user_id'])
            if not current_user:
                return jsonify({'message': 'مستخدم غير صحيح'}), 401
        except:
            return jsonify({'message': 'Token غير صحيح'}), 401
        
        return f(current_user, *args, **kwargs)
    return decorated

def permission_required(permission_name):
    """ديكوريتر للتحقق من وجود صلاحية معينة"""
    def decorator(f):
        @wraps(f)
        def decorated(current_user, *args, **kwargs):
            if not current_user.has_permission(permission_name):
                return jsonify({'message': 'ليس لديك صلاحية للوصول لهذه الخدمة'}), 403
            return f(current_user, *args, **kwargs)
        return decorated
    return decorator

@users_bp.route('/users', methods=['GET'])
@token_required
@permission_required('manage_users')
def get_users(current_user):
    """الحصول على قائمة المستخدمين"""
    try:
        users = User.query.all()
        return jsonify({
            'success': True,
            'users': [user.to_dict() for user in users]
        })
    except Exception as e:
        return jsonify({'success': False, 'message': str(e)}), 500

@users_bp.route('/users', methods=['POST'])
@token_required
@permission_required('add_users')
def create_user(current_user):
    """إنشاء مستخدم جديد"""
    try:
        data = request.get_json()
        
        # التحقق من البيانات المطلوبة
        required_fields = ['username', 'email', 'password', 'full_name', 'role_id']
        for field in required_fields:
            if field not in data:
                return jsonify({'success': False, 'message': f'حقل {field} مطلوب'}), 400
        
        # التحقق من عدم وجود مستخدم بنفس اسم المستخدم أو البريد الإلكتروني
        if User.query.filter_by(username=data['username']).first():
            return jsonify({'success': False, 'message': 'اسم المستخدم موجود بالفعل'}), 400
        
        if User.query.filter_by(email=data['email']).first():
            return jsonify({'success': False, 'message': 'البريد الإلكتروني موجود بالفعل'}), 400
        
        # التحقق من وجود الدور
        role = Role.query.get(data['role_id'])
        if not role:
            return jsonify({'success': False, 'message': 'الدور غير موجود'}), 400
        
        # إنشاء المستخدم الجديد
        new_user = User(
            username=data['username'],
            email=data['email'],
            full_name=data['full_name'],
            role_id=data['role_id']
        )
        new_user.set_password(data['password'])
        
        db.session.add(new_user)
        db.session.commit()
        
        return jsonify({
            'success': True,
            'message': 'تم إنشاء المستخدم بنجاح',
            'user': new_user.to_dict()
        })
    
    except Exception as e:
        db.session.rollback()
        return jsonify({'success': False, 'message': str(e)}), 500

@users_bp.route('/users/<int:user_id>', methods=['PUT'])
@token_required
@permission_required('edit_users')
def update_user(current_user, user_id):
    """تحديث بيانات مستخدم"""
    try:
        user = User.query.get(user_id)
        if not user:
            return jsonify({'success': False, 'message': 'المستخدم غير موجود'}), 404
        
        data = request.get_json()
        
        # تحديث البيانات
        if 'username' in data:
            # التحقق من عدم وجود مستخدم آخر بنفس اسم المستخدم
            existing_user = User.query.filter_by(username=data['username']).first()
            if existing_user and existing_user.id != user_id:
                return jsonify({'success': False, 'message': 'اسم المستخدم موجود بالفعل'}), 400
            user.username = data['username']
        
        if 'email' in data:
            # التحقق من عدم وجود مستخدم آخر بنفس البريد الإلكتروني
            existing_user = User.query.filter_by(email=data['email']).first()
            if existing_user and existing_user.id != user_id:
                return jsonify({'success': False, 'message': 'البريد الإلكتروني موجود بالفعل'}), 400
            user.email = data['email']
        
        if 'full_name' in data:
            user.full_name = data['full_name']
        
        if 'role_id' in data:
            role = Role.query.get(data['role_id'])
            if not role:
                return jsonify({'success': False, 'message': 'الدور غير موجود'}), 400
            user.role_id = data['role_id']
        
        if 'password' in data and data['password']:
            user.set_password(data['password'])
        
        if 'is_active' in data:
            user.is_active = data['is_active']
        
        db.session.commit()
        
        return jsonify({
            'success': True,
            'message': 'تم تحديث المستخدم بنجاح',
            'user': user.to_dict()
        })
    
    except Exception as e:
        db.session.rollback()
        return jsonify({'success': False, 'message': str(e)}), 500

@users_bp.route('/users/<int:user_id>', methods=['DELETE'])
@token_required
@permission_required('delete_users')
def delete_user(current_user, user_id):
    """حذف مستخدم"""
    try:
        user = User.query.get(user_id)
        if not user:
            return jsonify({'success': False, 'message': 'المستخدم غير موجود'}), 404
        
        # منع حذف المستخدم الحالي
        if user.id == current_user.id:
            return jsonify({'success': False, 'message': 'لا يمكن حذف حسابك الخاص'}), 400
        
        db.session.delete(user)
        db.session.commit()
        
        return jsonify({
            'success': True,
            'message': 'تم حذف المستخدم بنجاح'
        })
    
    except Exception as e:
        db.session.rollback()
        return jsonify({'success': False, 'message': str(e)}), 500

@users_bp.route('/roles', methods=['GET'])
@token_required
@permission_required('manage_roles')
def get_roles(current_user):
    """الحصول على قائمة الأدوار"""
    try:
        roles = Role.query.all()
        return jsonify({
            'success': True,
            'roles': [role.to_dict() for role in roles]
        })
    except Exception as e:
        return jsonify({'success': False, 'message': str(e)}), 500

@users_bp.route('/permissions', methods=['GET'])
@token_required
@permission_required('manage_roles')
def get_permissions(current_user):
    """الحصول على قائمة الصلاحيات"""
    try:
        permissions = Permission.query.all()
        return jsonify({
            'success': True,
            'permissions': [permission.to_dict() for permission in permissions]
        })
    except Exception as e:
        return jsonify({'success': False, 'message': str(e)}), 500

@users_bp.route('/roles/<int:role_id>/permissions', methods=['PUT'])
@token_required
@permission_required('assign_permissions')
def update_role_permissions(current_user, role_id):
    """تحديث صلاحيات دور معين"""
    try:
        role = Role.query.get(role_id)
        if not role:
            return jsonify({'success': False, 'message': 'الدور غير موجود'}), 404
        
        data = request.get_json()
        permission_ids = data.get('permission_ids', [])
        
        # مسح الصلاحيات الحالية
        role.permissions.clear()
        
        # إضافة الصلاحيات الجديدة
        for permission_id in permission_ids:
            permission = Permission.query.get(permission_id)
            if permission:
                role.permissions.append(permission)
        
        db.session.commit()
        
        return jsonify({
            'success': True,
            'message': 'تم تحديث صلاحيات الدور بنجاح',
            'role': role.to_dict()
        })
    
    except Exception as e:
        db.session.rollback()
        return jsonify({'success': False, 'message': str(e)}), 500

@users_bp.route('/profile', methods=['GET'])
@token_required
def get_profile(current_user):
    """الحصول على بيانات المستخدم الحالي"""
    try:
        return jsonify({
            'success': True,
            'user': current_user.to_dict()
        })
    except Exception as e:
        return jsonify({'success': False, 'message': str(e)}), 500

@users_bp.route('/profile', methods=['PUT'])
@token_required
def update_profile(current_user):
    """تحديث بيانات المستخدم الحالي"""
    try:
        data = request.get_json()
        
        # تحديث البيانات المسموح بها
        if 'full_name' in data:
            current_user.full_name = data['full_name']
        
        if 'email' in data:
            # التحقق من عدم وجود مستخدم آخر بنفس البريد الإلكتروني
            existing_user = User.query.filter_by(email=data['email']).first()
            if existing_user and existing_user.id != current_user.id:
                return jsonify({'success': False, 'message': 'البريد الإلكتروني موجود بالفعل'}), 400
            current_user.email = data['email']
        
        if 'password' in data and data['password']:
            current_user.set_password(data['password'])
        
        db.session.commit()
        
        return jsonify({
            'success': True,
            'message': 'تم تحديث الملف الشخصي بنجاح',
            'user': current_user.to_dict()
        })
    
    except Exception as e:
        db.session.rollback()
        return jsonify({'success': False, 'message': str(e)}), 500

