from flask import Blueprint, request, jsonify
from src.models.accounting import db, Product, IncomingItem, OutgoingItem
from src.models.auth import User
from datetime import datetime
from functools import wraps
import jwt
import os

products_bp = Blueprint('products', __name__)

def token_required(f):
    """ديكوريتر للتحقق من وجود token صحيح"""
    @wraps(f)
    def decorated(*args, **kwargs):
        token = request.headers.get('Authorization')
        if not token:
            return jsonify({'message': 'Token مفقود'}), 401
        
        try:
            if token.startswith('Bearer '):
                token = token[7:]
            data = jwt.decode(token, os.environ.get('SECRET_KEY', 'default-secret'), algorithms=['HS256'])
            current_user = User.query.get(data['user_id'])
            if not current_user:
                return jsonify({'message': 'مستخدم غير صحيح'}), 401
        except:
            return jsonify({'message': 'Token غير صحيح'}), 401
        
        return f(current_user, *args, **kwargs)
    return decorated

def permission_required(permission_name):
    """ديكوريتر للتحقق من وجود صلاحية معينة"""
    def decorator(f):
        @wraps(f)
        def decorated(current_user, *args, **kwargs):
            if not current_user.has_permission(permission_name):
                return jsonify({'message': 'ليس لديك صلاحية للوصول لهذه الخدمة'}), 403
            return f(current_user, *args, **kwargs)
        return decorated
    return decorator

@products_bp.route('/products', methods=['GET'])
@token_required
@permission_required('view_products')
def get_products(current_user):
    """الحصول على جميع المنتجات"""
    try:
        products = Product.query.all()
        return jsonify([product.to_dict() for product in products]), 200
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@products_bp.route('/products/<int:product_id>', methods=['GET'])
@token_required
@permission_required('view_products')
def get_product(current_user, product_id):
    """الحصول على منتج محدد"""
    try:
        product = Product.query.get_or_404(product_id)
        return jsonify(product.to_dict()), 200
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@products_bp.route('/products', methods=['POST'])
@token_required
@permission_required('add_products')
def create_product(current_user):
    """إنشاء منتج جديد"""
    try:
        data = request.get_json()
        
        # التحقق من البيانات المطلوبة
        if not data.get('type'):
            return jsonify({'error': 'نوع المنتج مطلوب'}), 400
        
        product = Product(
            type=data.get('type'),
            size=data.get('size'),
            brand=data.get('brand'),
            current_quantity=data.get('current_quantity', 0),
            import_price=data.get('import_price'),
            selling_price=data.get('selling_price')
        )
        
        db.session.add(product)
        db.session.commit()
        
        return jsonify(product.to_dict()), 201
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

@products_bp.route('/products/<int:product_id>', methods=['PUT'])
@token_required
@permission_required('edit_products')
def update_product(current_user, product_id):
    """تحديث منتج موجود"""
    try:
        product = Product.query.get_or_404(product_id)
        data = request.get_json()
        
        # تحديث البيانات
        if 'type' in data:
            product.type = data['type']
        if 'size' in data:
            product.size = data['size']
        if 'brand' in data:
            product.brand = data['brand']
        if 'current_quantity' in data:
            product.current_quantity = data['current_quantity']
        if 'import_price' in data:
            product.import_price = data['import_price']
        if 'selling_price' in data:
            product.selling_price = data['selling_price']
        
        db.session.commit()
        return jsonify(product.to_dict()), 200
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

@products_bp.route('/products/<int:product_id>', methods=['DELETE'])
@token_required
@permission_required('delete_products')
def delete_product(current_user, product_id):
    """حذف منتج"""
    try:
        product = Product.query.get_or_404(product_id)
        
        # التحقق من وجود عمليات مرتبطة
        if product.incoming_items or product.outgoing_items:
            return jsonify({'error': 'لا يمكن حذف المنتج لوجود عمليات مرتبطة به'}), 400
        
        db.session.delete(product)
        db.session.commit()
        
        return jsonify({'message': 'تم حذف المنتج بنجاح'}), 200
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

@products_bp.route('/products/search', methods=['GET'])
@token_required
@permission_required('view_products')
def search_products(current_user):
    """البحث في المنتجات"""
    try:
        query = request.args.get('q', '')
        products = Product.query.filter(
            Product.type.contains(query) |
            Product.brand.contains(query) |
            Product.size.contains(query)
        ).all()
        
        return jsonify([product.to_dict() for product in products]), 200
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@products_bp.route('/products/low-stock', methods=['GET'])
@token_required
@permission_required('view_products')
def get_low_stock_products(current_user):
    """الحصول على المنتجات ذات المخزون المنخفض"""
    try:
        threshold = request.args.get('threshold', 10, type=int)
        products = Product.query.filter(Product.current_quantity <= threshold).all()
        
        return jsonify([product.to_dict() for product in products]), 200
    except Exception as e:
        return jsonify({'error': str(e)}), 500

