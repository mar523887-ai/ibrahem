from flask import Blueprint, request, jsonify
from src.models.accounting import db, Product, IncomingItem
from src.models.auth import User
from datetime import datetime
from functools import wraps
import jwt
import os

incoming_bp = Blueprint('incoming', __name__)

def token_required(f):
    """ديكوريتر للتحقق من وجود token صحيح"""
    @wraps(f)
    def decorated(*args, **kwargs):
        token = request.headers.get('Authorization')
        if not token:
            return jsonify({'message': 'Token مفقود'}), 401
        
        try:
            if token.startswith('Bearer '):
                token = token[7:]
            data = jwt.decode(token, os.environ.get('SECRET_KEY', 'default-secret'), algorithms=['HS256'])
            current_user = User.query.get(data['user_id'])
            if not current_user:
                return jsonify({'message': 'مستخدم غير صحيح'}), 401
        except:
            return jsonify({'message': 'Token غير صحيح'}), 401
        
        return f(current_user, *args, **kwargs)
    return decorated

def permission_required(permission_name):
    """ديكوريتر للتحقق من وجود صلاحية معينة"""
    def decorator(f):
        @wraps(f)
        def decorated(current_user, *args, **kwargs):
            if not current_user.has_permission(permission_name):
                return jsonify({'message': 'ليس لديك صلاحية للوصول لهذه الخدمة'}), 403
            return f(current_user, *args, **kwargs)
        return decorated
    return decorator

@incoming_bp.route('/incoming', methods=['GET'])
@token_required
@permission_required('view_incoming')
def get_incoming_items(current_user):
    """الحصول على جميع الواردات"""
    try:
        page = request.args.get('page', 1, type=int)
        per_page = request.args.get('per_page', 50, type=int)
        
        incoming_items = IncomingItem.query.order_by(IncomingItem.date.desc()).paginate(
            page=page, per_page=per_page, error_out=False
        )
        
        return jsonify({
            'items': [item.to_dict() for item in incoming_items.items],
            'total': incoming_items.total,
            'pages': incoming_items.pages,
            'current_page': page
        }), 200
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@incoming_bp.route('/incoming/<int:incoming_id>', methods=['GET'])
@token_required
@permission_required('view_incoming')
def get_incoming_item(current_user, incoming_id):
    """الحصول على وارد محدد"""
    try:
        item = IncomingItem.query.get_or_404(incoming_id)
        return jsonify(item.to_dict()), 200
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@incoming_bp.route('/incoming', methods=['POST'])
def create_incoming_item():
    """إنشاء وارد جديد"""
    try:
        data = request.get_json()
        
        # التحقق من البيانات المطلوبة
        required_fields = ['product_id', 'supplier_name', 'quantity', 'price']
        for field in required_fields:
            if not data.get(field):
                return jsonify({'error': f'{field} مطلوب'}), 400
        
        # التحقق من وجود المنتج
        product = Product.query.get(data['product_id'])
        if not product:
            return jsonify({'error': 'المنتج غير موجود'}), 404
        
        # تحويل التاريخ إذا تم توفيره
        date = datetime.utcnow().date()
        if data.get('date'):
            try:
                date = datetime.strptime(data['date'], '%Y-%m-%d').date()
            except ValueError:
                return jsonify({'error': 'تنسيق التاريخ غير صحيح. استخدم YYYY-MM-DD'}), 400
        
        incoming_item = IncomingItem(
            product_id=data['product_id'],
            supplier_name=data['supplier_name'],
            quantity=data['quantity'],
            price=data['price'],
            date=date,
            notes=data.get('notes')
        )
        
        # تحديث كمية المنتج في المستودع
        product.current_quantity += data['quantity']
        
        # تحديث سعر الاستيراد إذا لم يكن محددًا
        if not product.import_price and data['quantity'] > 0:
            product.import_price = data['price'] / data['quantity']
        
        db.session.add(incoming_item)
        db.session.commit()
        
        return jsonify(incoming_item.to_dict()), 201
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

@incoming_bp.route('/incoming/<int:incoming_id>', methods=['PUT'])
def update_incoming_item(incoming_id):
    """تحديث وارد موجود"""
    try:
        item = IncomingItem.query.get_or_404(incoming_id)
        data = request.get_json()
        
        # حفظ الكمية القديمة لتحديث المخزون
        old_quantity = item.quantity
        
        # تحديث البيانات
        if 'supplier_name' in data:
            item.supplier_name = data['supplier_name']
        if 'quantity' in data:
            item.quantity = data['quantity']
        if 'price' in data:
            item.price = data['price']
        if 'notes' in data:
            item.notes = data['notes']
        if 'date' in data:
            try:
                item.date = datetime.strptime(data['date'], '%Y-%m-%d').date()
            except ValueError:
                return jsonify({'error': 'تنسيق التاريخ غير صحيح. استخدم YYYY-MM-DD'}), 400
        
        # تحديث كمية المنتج في المستودع
        if 'quantity' in data:
            quantity_diff = item.quantity - old_quantity
            item.product.current_quantity += quantity_diff
        
        db.session.commit()
        return jsonify(item.to_dict()), 200
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

@incoming_bp.route('/incoming/<int:incoming_id>', methods=['DELETE'])
def delete_incoming_item(incoming_id):
    """حذف وارد"""
    try:
        item = IncomingItem.query.get_or_404(incoming_id)
        
        # تحديث كمية المنتج في المستودع
        item.product.current_quantity -= item.quantity
        
        # التأكد من عدم وجود كمية سالبة
        if item.product.current_quantity < 0:
            return jsonify({'error': 'لا يمكن حذف هذا الوارد لأنه سيؤدي إلى كمية سالبة في المستودع'}), 400
        
        db.session.delete(item)
        db.session.commit()
        
        return jsonify({'message': 'تم حذف الوارد بنجاح'}), 200
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

@incoming_bp.route('/incoming/by-supplier', methods=['GET'])
def get_incoming_by_supplier():
    """الحصول على الواردات حسب المورد"""
    try:
        supplier = request.args.get('supplier')
        if not supplier:
            return jsonify({'error': 'اسم المورد مطلوب'}), 400
        
        items = IncomingItem.query.filter(
            IncomingItem.supplier_name.contains(supplier)
        ).order_by(IncomingItem.date.desc()).all()
        
        return jsonify([item.to_dict() for item in items]), 200
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@incoming_bp.route('/incoming/by-date-range', methods=['GET'])
def get_incoming_by_date_range():
    """الحصول على الواردات في فترة زمنية محددة"""
    try:
        start_date = request.args.get('start_date')
        end_date = request.args.get('end_date')
        
        if not start_date or not end_date:
            return jsonify({'error': 'تاريخ البداية والنهاية مطلوبان'}), 400
        
        try:
            start = datetime.strptime(start_date, '%Y-%m-%d').date()
            end = datetime.strptime(end_date, '%Y-%m-%d').date()
        except ValueError:
            return jsonify({'error': 'تنسيق التاريخ غير صحيح. استخدم YYYY-MM-DD'}), 400
        
        items = IncomingItem.query.filter(
            IncomingItem.date >= start,
            IncomingItem.date <= end
        ).order_by(IncomingItem.date.desc()).all()
        
        return jsonify([item.to_dict() for item in items]), 200
    except Exception as e:
        return jsonify({'error': str(e)}), 500

