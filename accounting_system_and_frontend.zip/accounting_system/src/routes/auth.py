from flask import Blueprint, request, jsonify
from functools import wraps
from src.models.auth import db, User, Role, Permission, init_default_data
from datetime import datetime

auth_bp = Blueprint('auth', __name__)

def token_required(f):
    """ديكوريتر للتحقق من وجود token صحيح"""
    @wraps(f)
    def decorated(*args, **kwargs):
        token = None
        
        # البحث عن token في header
        if 'Authorization' in request.headers:
            auth_header = request.headers['Authorization']
            try:
                token = auth_header.split(" ")[1]  # Bearer TOKEN
            except IndexError:
                return jsonify({'error': 'تنسيق token غير صحيح'}), 401
        
        if not token:
            return jsonify({'error': 'Token مطلوب'}), 401
        
        try:
            current_user = User.verify_token(token)
            if current_user is None:
                return jsonify({'error': 'Token غير صحيح أو منتهي الصلاحية'}), 401
            
            if not current_user.is_active:
                return jsonify({'error': 'المستخدم غير نشط'}), 401
                
        except Exception as e:
            return jsonify({'error': 'Token غير صحيح'}), 401
        
        return f(current_user, *args, **kwargs)
    
    return decorated

def permission_required(permission_name):
    """ديكوريتر للتحقق من وجود صلاحية معينة"""
    def decorator(f):
        @wraps(f)
        def decorated(current_user, *args, **kwargs):
            if not current_user.has_permission(permission_name):
                return jsonify({'error': 'ليس لديك صلاحية للوصول لهذا المورد'}), 403
            return f(current_user, *args, **kwargs)
        return decorated
    return decorator

@auth_bp.route('/login', methods=['POST'])
def login():
    """تسجيل الدخول"""
    try:
        data = request.get_json()
        
        if not data.get('username') or not data.get('password'):
            return jsonify({'error': 'اسم المستخدم وكلمة المرور مطلوبان'}), 400
        
        user = User.query.filter_by(username=data['username']).first()
        
        if not user or not user.check_password(data['password']):
            return jsonify({'error': 'اسم المستخدم أو كلمة المرور غير صحيحة'}), 401
        
        if not user.is_active:
            return jsonify({'error': 'المستخدم غير نشط'}), 401
        
        # تحديث آخر تسجيل دخول
        user.last_login = datetime.utcnow()
        db.session.commit()
        
        # إنشاء token
        token = user.generate_token()
        
        return jsonify({
            'success': True,
            'message': 'تم تسجيل الدخول بنجاح',
            'token': token,
            'user': user.to_dict()
        }), 200
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@auth_bp.route('/register', methods=['POST'])
@token_required
@permission_required('manage_users')
def register(current_user):
    """تسجيل مستخدم جديد (يتطلب صلاحية إدارة المستخدمين)"""
    try:
        data = request.get_json()
        
        # التحقق من البيانات المطلوبة
        required_fields = ['username', 'email', 'password', 'full_name', 'role_id']
        for field in required_fields:
            if not data.get(field):
                return jsonify({'error': f'{field} مطلوب'}), 400
        
        # التحقق من عدم وجود المستخدم مسبقاً
        if User.query.filter_by(username=data['username']).first():
            return jsonify({'error': 'اسم المستخدم موجود مسبقاً'}), 400
        
        if User.query.filter_by(email=data['email']).first():
            return jsonify({'error': 'البريد الإلكتروني موجود مسبقاً'}), 400
        
        # التحقق من وجود الدور
        role = Role.query.get(data['role_id'])
        if not role:
            return jsonify({'error': 'الدور غير موجود'}), 400
        
        # إنشاء المستخدم الجديد
        user = User(
            username=data['username'],
            email=data['email'],
            full_name=data['full_name'],
            role_id=data['role_id']
        )
        user.set_password(data['password'])
        
        db.session.add(user)
        db.session.commit()
        
        return jsonify({
            'message': 'تم إنشاء المستخدم بنجاح',
            'user': user.to_dict()
        }), 201
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

@auth_bp.route('/profile', methods=['GET'])
@token_required
def get_profile(current_user):
    """الحصول على معلومات المستخدم الحالي"""
    return jsonify({
        'success': True,
        'user': current_user.to_dict()
    }), 200

@auth_bp.route('/profile', methods=['PUT'])
@token_required
def update_profile(current_user):
    """تحديث معلومات المستخدم الحالي"""
    try:
        data = request.get_json()
        
        # تحديث البيانات المسموح بها
        if 'full_name' in data:
            current_user.full_name = data['full_name']
        
        if 'email' in data:
            # التحقق من عدم وجود البريد الإلكتروني لمستخدم آخر
            existing_user = User.query.filter_by(email=data['email']).first()
            if existing_user and existing_user.id != current_user.id:
                return jsonify({'error': 'البريد الإلكتروني موجود مسبقاً'}), 400
            current_user.email = data['email']
        
        if 'password' in data:
            if len(data['password']) < 6:
                return jsonify({'error': 'كلمة المرور يجب أن تكون 6 أحرف على الأقل'}), 400
            current_user.set_password(data['password'])
        
        db.session.commit()
        
        return jsonify({
            'message': 'تم تحديث الملف الشخصي بنجاح',
            'user': current_user.to_dict()
        }), 200
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

@auth_bp.route('/users', methods=['GET'])
@token_required
@permission_required('manage_users')
def get_users(current_user):
    """الحصول على جميع المستخدمين"""
    try:
        users = User.query.all()
        return jsonify([user.to_dict() for user in users]), 200
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@auth_bp.route('/users/<int:user_id>', methods=['PUT'])
@token_required
@permission_required('manage_users')
def update_user(current_user, user_id):
    """تحديث مستخدم"""
    try:
        user = User.query.get_or_404(user_id)
        data = request.get_json()
        
        if 'full_name' in data:
            user.full_name = data['full_name']
        
        if 'email' in data:
            existing_user = User.query.filter_by(email=data['email']).first()
            if existing_user and existing_user.id != user.id:
                return jsonify({'error': 'البريد الإلكتروني موجود مسبقاً'}), 400
            user.email = data['email']
        
        if 'role_id' in data:
            role = Role.query.get(data['role_id'])
            if not role:
                return jsonify({'error': 'الدور غير موجود'}), 400
            user.role_id = data['role_id']
        
        if 'is_active' in data:
            user.is_active = data['is_active']
        
        if 'password' in data and data['password']:
            if len(data['password']) < 6:
                return jsonify({'error': 'كلمة المرور يجب أن تكون 6 أحرف على الأقل'}), 400
            user.set_password(data['password'])
        
        db.session.commit()
        
        return jsonify({
            'message': 'تم تحديث المستخدم بنجاح',
            'user': user.to_dict()
        }), 200
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

@auth_bp.route('/users/<int:user_id>', methods=['DELETE'])
@token_required
@permission_required('manage_users')
def delete_user(current_user, user_id):
    """حذف مستخدم"""
    try:
        if user_id == current_user.id:
            return jsonify({'error': 'لا يمكنك حذف حسابك الخاص'}), 400
        
        user = User.query.get_or_404(user_id)
        db.session.delete(user)
        db.session.commit()
        
        return jsonify({'message': 'تم حذف المستخدم بنجاح'}), 200
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

@auth_bp.route('/roles', methods=['GET'])
@token_required
@permission_required('manage_roles')
def get_roles(current_user):
    """الحصول على جميع الأدوار"""
    try:
        roles = Role.query.all()
        return jsonify([role.to_dict() for role in roles]), 200
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@auth_bp.route('/permissions', methods=['GET'])
@token_required
@permission_required('manage_roles')
def get_permissions(current_user):
    """الحصول على جميع الصلاحيات"""
    try:
        permissions = Permission.query.all()
        return jsonify([perm.to_dict() for perm in permissions]), 200
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@auth_bp.route('/init-data', methods=['POST'])
def initialize_data():
    """تهيئة البيانات الافتراضية (للاستخدام مرة واحدة فقط)"""
    try:
        # التحقق من عدم وجود مستخدمين مسبقاً
        if User.query.count() > 0:
            return jsonify({'error': 'البيانات موجودة مسبقاً'}), 400
        
        init_default_data()
        
        return jsonify({
            'message': 'تم تهيئة البيانات الافتراضية بنجاح',
            'admin_credentials': {
                'username': 'admin',
                'password': 'admin123'
            }
        }), 200
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

