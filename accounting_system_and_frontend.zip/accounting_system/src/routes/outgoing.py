from flask import Blueprint, request, jsonify
from src.models.accounting import db, Product, OutgoingItem
from datetime import datetime

outgoing_bp = Blueprint('outgoing', __name__)

@outgoing_bp.route('/outgoing', methods=['GET'])
def get_outgoing_items():
    """الحصول على جميع الصادرات"""
    try:
        page = request.args.get('page', 1, type=int)
        per_page = request.args.get('per_page', 50, type=int)
        
        outgoing_items = OutgoingItem.query.order_by(OutgoingItem.date.desc()).paginate(
            page=page, per_page=per_page, error_out=False
        )
        
        return jsonify({
            'items': [item.to_dict() for item in outgoing_items.items],
            'total': outgoing_items.total,
            'pages': outgoing_items.pages,
            'current_page': page
        }), 200
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@outgoing_bp.route('/outgoing/<int:outgoing_id>', methods=['GET'])
def get_outgoing_item(outgoing_id):
    """الحصول على صادر محدد"""
    try:
        item = OutgoingItem.query.get_or_404(outgoing_id)
        return jsonify(item.to_dict()), 200
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@outgoing_bp.route('/outgoing', methods=['POST'])
def create_outgoing_item():
    """إنشاء صادر جديد"""
    try:
        data = request.get_json()
        
        # التحقق من البيانات المطلوبة
        required_fields = ['product_id', 'customer_name', 'quantity', 'price']
        for field in required_fields:
            if not data.get(field):
                return jsonify({'error': f'{field} مطلوب'}), 400
        
        # التحقق من وجود المنتج
        product = Product.query.get(data['product_id'])
        if not product:
            return jsonify({'error': 'المنتج غير موجود'}), 404
        
        # التحقق من توفر الكمية المطلوبة
        if product.current_quantity < data['quantity']:
            return jsonify({'error': f'الكمية المتوفرة غير كافية. المتوفر: {product.current_quantity}'}), 400
        
        # تحويل التاريخ إذا تم توفيره
        date = datetime.utcnow().date()
        if data.get('date'):
            try:
                date = datetime.strptime(data['date'], '%Y-%m-%d').date()
            except ValueError:
                return jsonify({'error': 'تنسيق التاريخ غير صحيح. استخدم YYYY-MM-DD'}), 400
        
        outgoing_item = OutgoingItem(
            product_id=data['product_id'],
            customer_name=data['customer_name'],
            quantity=data['quantity'],
            price=data['price'],
            date=date,
            notes=data.get('notes')
        )
        
        # تحديث كمية المنتج في المستودع
        product.current_quantity -= data['quantity']
        
        # تحديث سعر البيع إذا لم يكن محددًا
        if not product.selling_price and data['quantity'] > 0:
            product.selling_price = data['price'] / data['quantity']
        
        db.session.add(outgoing_item)
        db.session.commit()
        
        return jsonify(outgoing_item.to_dict()), 201
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

@outgoing_bp.route('/outgoing/<int:outgoing_id>', methods=['PUT'])
def update_outgoing_item(outgoing_id):
    """تحديث صادر موجود"""
    try:
        item = OutgoingItem.query.get_or_404(outgoing_id)
        data = request.get_json()
        
        # حفظ الكمية القديمة لتحديث المخزون
        old_quantity = item.quantity
        
        # تحديث البيانات
        if 'customer_name' in data:
            item.customer_name = data['customer_name']
        if 'quantity' in data:
            # التحقق من توفر الكمية الجديدة
            quantity_diff = data['quantity'] - old_quantity
            if item.product.current_quantity < quantity_diff:
                return jsonify({'error': f'الكمية المتوفرة غير كافية. المتوفر: {item.product.current_quantity}'}), 400
            item.quantity = data['quantity']
        if 'price' in data:
            item.price = data['price']
        if 'notes' in data:
            item.notes = data['notes']
        if 'date' in data:
            try:
                item.date = datetime.strptime(data['date'], '%Y-%m-%d').date()
            except ValueError:
                return jsonify({'error': 'تنسيق التاريخ غير صحيح. استخدم YYYY-MM-DD'}), 400
        
        # تحديث كمية المنتج في المستودع
        if 'quantity' in data:
            quantity_diff = old_quantity - item.quantity
            item.product.current_quantity += quantity_diff
        
        db.session.commit()
        return jsonify(item.to_dict()), 200
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

@outgoing_bp.route('/outgoing/<int:outgoing_id>', methods=['DELETE'])
def delete_outgoing_item(outgoing_id):
    """حذف صادر"""
    try:
        item = OutgoingItem.query.get_or_404(outgoing_id)
        
        # إعادة الكمية إلى المستودع
        item.product.current_quantity += item.quantity
        
        db.session.delete(item)
        db.session.commit()
        
        return jsonify({'message': 'تم حذف الصادر بنجاح'}), 200
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

@outgoing_bp.route('/outgoing/by-customer', methods=['GET'])
def get_outgoing_by_customer():
    """الحصول على الصادرات حسب العميل"""
    try:
        customer = request.args.get('customer')
        if not customer:
            return jsonify({'error': 'اسم العميل مطلوب'}), 400
        
        items = OutgoingItem.query.filter(
            OutgoingItem.customer_name.contains(customer)
        ).order_by(OutgoingItem.date.desc()).all()
        
        return jsonify([item.to_dict() for item in items]), 200
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@outgoing_bp.route('/outgoing/by-date-range', methods=['GET'])
def get_outgoing_by_date_range():
    """الحصول على الصادرات في فترة زمنية محددة"""
    try:
        start_date = request.args.get('start_date')
        end_date = request.args.get('end_date')
        
        if not start_date or not end_date:
            return jsonify({'error': 'تاريخ البداية والنهاية مطلوبان'}), 400
        
        try:
            start = datetime.strptime(start_date, '%Y-%m-%d').date()
            end = datetime.strptime(end_date, '%Y-%m-%d').date()
        except ValueError:
            return jsonify({'error': 'تنسيق التاريخ غير صحيح. استخدم YYYY-MM-DD'}), 400
        
        items = OutgoingItem.query.filter(
            OutgoingItem.date >= start,
            OutgoingItem.date <= end
        ).order_by(OutgoingItem.date.desc()).all()
        
        return jsonify([item.to_dict() for item in items]), 200
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@outgoing_bp.route('/outgoing/invoice/<int:outgoing_id>', methods=['GET'])
def generate_invoice(outgoing_id):
    """إنشاء فاتورة للصادر"""
    try:
        item = OutgoingItem.query.get_or_404(outgoing_id)
        
        invoice_data = {
            'invoice_number': f'INV-{item.outgoing_id:06d}',
            'date': item.date.isoformat(),
            'customer_name': item.customer_name,
            'product': {
                'type': item.product.type,
                'brand': item.product.brand,
                'size': item.product.size
            },
            'quantity': item.quantity,
            'unit_price': item.unit_price,
            'total_price': item.price,
            'notes': item.notes
        }
        
        return jsonify(invoice_data), 200
    except Exception as e:
        return jsonify({'error': str(e)}), 500

