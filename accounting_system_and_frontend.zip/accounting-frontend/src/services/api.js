import axios from 'axios';

// عنوان الخادم الخلفي
const BASE_URL = 'https://g8h3ilc17v1y.manus.space/api';

// إنشاء instance من axios
const api = axios.create({
  baseURL: BASE_URL,
  timeout: 10000,
  headers: {
    'Content-Type': 'application/json',
  },
});

// إضافة token تلقائياً للطلبات
api.interceptors.request.use(
  (config) => {
    const token = localStorage.getItem('userToken');
    if (token) {
      config.headers.Authorization = `Bearer ${token}`;
    }
    return config;
  },
  (error) => {
    return Promise.reject(error);
  }
);

// معالجة الاستجابات والأخطاء
api.interceptors.response.use(
  (response) => {
    return response;
  },
  (error) => {
    if (error.response?.status === 401) {
      // إزالة token المنتهي الصلاحية
      localStorage.removeItem('userToken');
      localStorage.removeItem('userData');
      // إعادة تحميل الصفحة لإظهار شاشة تسجيل الدخول
      window.location.reload();
    }
    return Promise.reject(error);
  }
);

export default api;

