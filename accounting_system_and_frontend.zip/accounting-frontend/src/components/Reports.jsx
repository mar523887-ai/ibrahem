import { useState, useEffect } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { 
  BarChart3, 
  TrendingUp, 
  TrendingDown, 
  Package,
  Calendar,
  Download,
  DollarSign,
  Users,
  ShoppingCart
} from 'lucide-react'

const API_BASE = '/api'

function Reports() {
  const [reportType, setReportType] = useState('inventory')
  const [reportData, setReportData] = useState(null)
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState(null)
  const [dateRange, setDateRange] = useState({
    start_date: new Date(Date.now() - 30 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
    end_date: new Date().toISOString().split('T')[0]
  })

  const reportTypes = [
    { value: 'inventory', label: 'تقرير المخزون', icon: Package },
    { value: 'sales', label: 'تقرير المبيعات', icon: TrendingUp },
    { value: 'purchases', label: 'تقرير المشتريات', icon: TrendingDown },
    { value: 'profit-loss', label: 'تقرير الأرباح والخسائر', icon: DollarSign }
  ]

  useEffect(() => {
    generateReport()
  }, [reportType])

  const generateReport = async () => {
    try {
      setLoading(true)
      setError(null)
      
      let url = `${API_BASE}/reports/${reportType}`
      
      if (reportType !== 'inventory') {
        url += `?start_date=${dateRange.start_date}&end_date=${dateRange.end_date}`
      }

      const response = await fetch(url)
      if (!response.ok) {
        throw new Error('فشل في إنشاء التقرير')
      }
      
      const data = await response.json()
      setReportData(data)
    } catch (err) {
      setError(err.message)
    } finally {
      setLoading(false)
    }
  }

  const formatCurrency = (amount) => {
    return `${parseFloat(amount || 0).toFixed(2)} ر.س`
  }

  const formatDate = (dateString) => {
    return new Date(dateString).toLocaleDateString('ar-SA')
  }

  const renderInventoryReport = () => {
    if (!reportData) return null

    return (
      <div className="space-y-6">
        {/* Summary Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600">إجمالي المنتجات</p>
                  <p className="text-2xl font-bold">{reportData.summary.total_products}</p>
                </div>
                <Package className="h-8 w-8 text-blue-600" />
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600">قيمة المخزون</p>
                  <p className="text-2xl font-bold">{formatCurrency(reportData.summary.total_value)}</p>
                </div>
                <DollarSign className="h-8 w-8 text-green-600" />
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600">مخزون منخفض</p>
                  <p className="text-2xl font-bold text-red-600">{reportData.summary.low_stock_count}</p>
                </div>
                <Package className="h-8 w-8 text-red-600" />
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Inventory Details */}
        <Card>
          <CardHeader>
            <CardTitle>تفاصيل المخزون</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b">
                    <th className="text-right p-2">المنتج</th>
                    <th className="text-right p-2">الماركة</th>
                    <th className="text-right p-2">المقاس</th>
                    <th className="text-right p-2">الكمية</th>
                    <th className="text-right p-2">سعر الاستيراد</th>
                    <th className="text-right p-2">سعر البيع</th>
                    <th className="text-right p-2">القيمة الإجمالية</th>
                    <th className="text-right p-2">الحالة</th>
                  </tr>
                </thead>
                <tbody>
                  {reportData.inventory.map((item, index) => (
                    <tr key={index} className="border-b hover:bg-gray-50">
                      <td className="p-2">{item.type}</td>
                      <td className="p-2">{item.brand || '-'}</td>
                      <td className="p-2">{item.size || '-'}</td>
                      <td className="p-2">{item.current_quantity}</td>
                      <td className="p-2">{formatCurrency(item.import_price)}</td>
                      <td className="p-2">{formatCurrency(item.selling_price)}</td>
                      <td className="p-2">{formatCurrency(item.total_value)}</td>
                      <td className="p-2">
                        {item.is_low_stock ? (
                          <span className="text-red-600 text-xs bg-red-100 px-2 py-1 rounded">
                            مخزون منخفض
                          </span>
                        ) : (
                          <span className="text-green-600 text-xs bg-green-100 px-2 py-1 rounded">
                            متوفر
                          </span>
                        )}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </CardContent>
        </Card>
      </div>
    )
  }

  const renderSalesReport = () => {
    if (!reportData) return null

    return (
      <div className="space-y-6">
        {/* Summary Cards */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600">إجمالي المبيعات</p>
                  <p className="text-2xl font-bold">{formatCurrency(reportData.summary.total_sales)}</p>
                </div>
                <DollarSign className="h-8 w-8 text-green-600" />
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600">إجمالي الربح</p>
                  <p className="text-2xl font-bold">{formatCurrency(reportData.summary.total_profit)}</p>
                </div>
                <TrendingUp className="h-8 w-8 text-blue-600" />
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600">عدد العمليات</p>
                  <p className="text-2xl font-bold">{reportData.summary.transactions_count}</p>
                </div>
                <ShoppingCart className="h-8 w-8 text-purple-600" />
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600">متوسط قيمة العملية</p>
                  <p className="text-2xl font-bold">{formatCurrency(reportData.summary.average_transaction_value)}</p>
                </div>
                <BarChart3 className="h-8 w-8 text-orange-600" />
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Sales by Product */}
        <Card>
          <CardHeader>
            <CardTitle>المبيعات حسب المنتج</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {reportData.by_product.map((item, index) => (
                <div key={index} className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                  <div>
                    <p className="font-medium">{item.product_type} - {item.product_brand}</p>
                    <p className="text-sm text-gray-600">الكمية: {item.total_quantity}</p>
                  </div>
                  <div className="text-left">
                    <p className="font-bold">{formatCurrency(item.total_sales)}</p>
                    <p className="text-sm text-green-600">ربح: {formatCurrency(item.total_profit)}</p>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Sales by Customer */}
        <Card>
          <CardHeader>
            <CardTitle>المبيعات حسب العميل</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {reportData.by_customer.map((item, index) => (
                <div key={index} className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                  <div>
                    <p className="font-medium">{item.customer_name}</p>
                    <p className="text-sm text-gray-600">
                      {item.transactions_count} عملية - {item.total_quantity} قطعة
                    </p>
                  </div>
                  <div className="text-left">
                    <p className="font-bold">{formatCurrency(item.total_sales)}</p>
                    <p className="text-sm text-green-600">ربح: {formatCurrency(item.total_profit)}</p>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    )
  }

  const renderPurchasesReport = () => {
    if (!reportData) return null

    return (
      <div className="space-y-6">
        {/* Summary Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600">إجمالي المشتريات</p>
                  <p className="text-2xl font-bold">{formatCurrency(reportData.summary.total_purchases)}</p>
                </div>
                <DollarSign className="h-8 w-8 text-red-600" />
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600">عدد العمليات</p>
                  <p className="text-2xl font-bold">{reportData.summary.transactions_count}</p>
                </div>
                <ShoppingCart className="h-8 w-8 text-blue-600" />
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600">متوسط قيمة العملية</p>
                  <p className="text-2xl font-bold">{formatCurrency(reportData.summary.average_transaction_value)}</p>
                </div>
                <BarChart3 className="h-8 w-8 text-purple-600" />
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Purchases by Supplier */}
        <Card>
          <CardHeader>
            <CardTitle>المشتريات حسب المورد</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {reportData.by_supplier.map((item, index) => (
                <div key={index} className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                  <div>
                    <p className="font-medium">{item.supplier_name}</p>
                    <p className="text-sm text-gray-600">
                      {item.transactions_count} عملية - {item.total_quantity} قطعة
                    </p>
                  </div>
                  <div className="text-left">
                    <p className="font-bold">{formatCurrency(item.total_purchases)}</p>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    )
  }

  const renderProfitLossReport = () => {
    if (!reportData) return null

    const profitMargin = reportData.profit_margin || 0

    return (
      <div className="space-y-6">
        {/* Summary Cards */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600">الإيرادات</p>
                  <p className="text-2xl font-bold text-green-600">{formatCurrency(reportData.revenue)}</p>
                </div>
                <TrendingUp className="h-8 w-8 text-green-600" />
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600">تكلفة البضائع</p>
                  <p className="text-2xl font-bold text-red-600">{formatCurrency(reportData.cost_of_goods)}</p>
                </div>
                <TrendingDown className="h-8 w-8 text-red-600" />
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600">إجمالي الربح</p>
                  <p className="text-2xl font-bold text-blue-600">{formatCurrency(reportData.gross_profit)}</p>
                </div>
                <DollarSign className="h-8 w-8 text-blue-600" />
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600">هامش الربح</p>
                  <p className="text-2xl font-bold text-purple-600">{profitMargin.toFixed(1)}%</p>
                </div>
                <BarChart3 className="h-8 w-8 text-purple-600" />
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Detailed Analysis */}
        <Card>
          <CardHeader>
            <CardTitle>تحليل مفصل</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-3">
                  <h4 className="font-semibold text-gray-800">المبيعات</h4>
                  <div className="flex justify-between">
                    <span>عدد عمليات البيع:</span>
                    <span className="font-medium">{reportData.transactions.sales_count}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>إجمالي الإيرادات:</span>
                    <span className="font-medium text-green-600">{formatCurrency(reportData.revenue)}</span>
                  </div>
                </div>
                
                <div className="space-y-3">
                  <h4 className="font-semibold text-gray-800">المشتريات</h4>
                  <div className="flex justify-between">
                    <span>عدد عمليات الشراء:</span>
                    <span className="font-medium">{reportData.transactions.purchases_count}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>إجمالي التكلفة:</span>
                    <span className="font-medium text-red-600">{formatCurrency(reportData.cost_of_goods)}</span>
                  </div>
                </div>
              </div>
              
              <div className="pt-4 border-t">
                <div className="flex justify-between items-center">
                  <span className="text-lg font-semibold">صافي الربح:</span>
                  <span className={`text-xl font-bold ${reportData.gross_profit >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                    {formatCurrency(reportData.gross_profit)}
                  </span>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    )
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <h2 className="text-2xl font-bold text-gray-800">التقارير</h2>
      </div>

      {/* Report Controls */}
      <Card>
        <CardContent className="p-6">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <div>
              <Label htmlFor="reportType">نوع التقرير</Label>
              <Select value={reportType} onValueChange={setReportType}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {reportTypes.map((type) => (
                    <SelectItem key={type.value} value={type.value}>
                      {type.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            
            {reportType !== 'inventory' && (
              <>
                <div>
                  <Label htmlFor="start_date">من تاريخ</Label>
                  <Input
                    id="start_date"
                    type="date"
                    value={dateRange.start_date}
                    onChange={(e) => setDateRange({...dateRange, start_date: e.target.value})}
                  />
                </div>
                
                <div>
                  <Label htmlFor="end_date">إلى تاريخ</Label>
                  <Input
                    id="end_date"
                    type="date"
                    value={dateRange.end_date}
                    onChange={(e) => setDateRange({...dateRange, end_date: e.target.value})}
                  />
                </div>
              </>
            )}
            
            <div className="flex items-end">
              <Button onClick={generateReport} disabled={loading} className="w-full">
                {loading ? 'جاري الإنشاء...' : 'إنشاء التقرير'}
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Report Content */}
      {loading && (
        <div className="flex items-center justify-center h-64">
          <div className="text-lg text-gray-600">جاري إنشاء التقرير...</div>
        </div>
      )}

      {error && (
        <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded">
          {error}
        </div>
      )}

      {reportData && !loading && (
        <>
          {reportType === 'inventory' && renderInventoryReport()}
          {reportType === 'sales' && renderSalesReport()}
          {reportType === 'purchases' && renderPurchasesReport()}
          {reportType === 'profit-loss' && renderProfitLossReport()}
        </>
      )}
    </div>
  )
}

export default Reports

