import { useState, useEffect } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Textarea } from '@/components/ui/textarea'
import { Badge } from '@/components/ui/badge'
import { 
  Plus, 
  TrendingDown, 
  Calendar,
  User,
  Package,
  FileText,
  DollarSign
} from 'lucide-react'

const API_BASE = '/api'

function Outgoing() {
  const [outgoingItems, setOutgoingItems] = useState([])
  const [products, setProducts] = useState([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState(null)
  const [showAddForm, setShowAddForm] = useState(false)
  const [formData, setFormData] = useState({
    product_id: '',
    customer_name: '',
    quantity: '',
    price: '',
    date: new Date().toISOString().split('T')[0],
    notes: ''
  })

  useEffect(() => {
    fetchOutgoingItems()
    fetchProducts()
  }, [])

  const fetchOutgoingItems = async () => {
    try {
      setLoading(true)
      const response = await fetch(`${API_BASE}/outgoing`)
      if (!response.ok) {
        throw new Error('فشل في تحميل الصادرات')
      }
      const data = await response.json()
      setOutgoingItems(data.items || [])
    } catch (err) {
      setError(err.message)
    } finally {
      setLoading(false)
    }
  }

  const fetchProducts = async () => {
    try {
      const response = await fetch(`${API_BASE}/products`)
      if (!response.ok) {
        throw new Error('فشل في تحميل المنتجات')
      }
      const data = await response.json()
      setProducts(data.filter(product => product.current_quantity > 0))
    } catch (err) {
      setError(err.message)
    }
  }

  const handleSubmit = async (e) => {
    e.preventDefault()
    try {
      const response = await fetch(`${API_BASE}/outgoing`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          ...formData,
          product_id: parseInt(formData.product_id),
          quantity: parseInt(formData.quantity),
          price: parseFloat(formData.price)
        }),
      })

      if (!response.ok) {
        const errorData = await response.json()
        throw new Error(errorData.error || 'فشل في حفظ الصادر')
      }

      await fetchOutgoingItems()
      await fetchProducts() // تحديث قائمة المنتجات لإظهار الكميات الجديدة
      resetForm()
    } catch (err) {
      setError(err.message)
    }
  }

  const generateInvoice = async (outgoingId) => {
    try {
      const response = await fetch(`${API_BASE}/outgoing/invoice/${outgoingId}`)
      if (!response.ok) {
        throw new Error('فشل في إنشاء الفاتورة')
      }
      const invoiceData = await response.json()
      
      // إنشاء نافذة جديدة لطباعة الفاتورة
      const printWindow = window.open('', '_blank')
      printWindow.document.write(`
        <html dir="rtl">
          <head>
            <title>فاتورة رقم ${invoiceData.invoice_number}</title>
            <style>
              body { font-family: Arial, sans-serif; margin: 20px; }
              .header { text-align: center; margin-bottom: 30px; }
              .invoice-details { margin-bottom: 20px; }
              .product-details { border: 1px solid #ddd; padding: 15px; margin: 10px 0; }
              .total { font-weight: bold; font-size: 18px; }
            </style>
          </head>
          <body>
            <div class="header">
              <h1>فاتورة مبيعات</h1>
              <p>رقم الفاتورة: ${invoiceData.invoice_number}</p>
            </div>
            <div class="invoice-details">
              <p><strong>التاريخ:</strong> ${new Date(invoiceData.date).toLocaleDateString('ar-SA')}</p>
              <p><strong>اسم العميل:</strong> ${invoiceData.customer_name}</p>
            </div>
            <div class="product-details">
              <h3>تفاصيل المنتج</h3>
              <p><strong>النوع:</strong> ${invoiceData.product.type}</p>
              <p><strong>الماركة:</strong> ${invoiceData.product.brand || 'غير محدد'}</p>
              <p><strong>المقاس:</strong> ${invoiceData.product.size || 'غير محدد'}</p>
              <p><strong>الكمية:</strong> ${invoiceData.quantity}</p>
              <p><strong>سعر الوحدة:</strong> ${invoiceData.unit_price} ر.س</p>
              <p class="total"><strong>المجموع:</strong> ${invoiceData.total_price} ر.س</p>
            </div>
            ${invoiceData.notes ? `<p><strong>ملاحظات:</strong> ${invoiceData.notes}</p>` : ''}
          </body>
        </html>
      `)
      printWindow.document.close()
      printWindow.print()
    } catch (err) {
      setError(err.message)
    }
  }

  const resetForm = () => {
    setFormData({
      product_id: '',
      customer_name: '',
      quantity: '',
      price: '',
      date: new Date().toISOString().split('T')[0],
      notes: ''
    })
    setShowAddForm(false)
  }

  const formatDate = (dateString) => {
    return new Date(dateString).toLocaleDateString('ar-SA')
  }

  const selectedProduct = products.find(p => p.product_id === parseInt(formData.product_id))

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="text-lg text-gray-600">جاري تحميل الصادرات...</div>
      </div>
    )
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <h2 className="text-2xl font-bold text-gray-800">إدارة الصادرات</h2>
        <Button 
          onClick={() => setShowAddForm(true)}
          className="flex items-center gap-2"
        >
          <Plus className="h-4 w-4" />
          تسجيل صادر جديد
        </Button>
      </div>

      {/* Add Form */}
      {showAddForm && (
        <Card>
          <CardHeader>
            <CardTitle>تسجيل صادر جديد</CardTitle>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="product_id">المنتج *</Label>
                  <Select 
                    value={formData.product_id} 
                    onValueChange={(value) => setFormData({...formData, product_id: value})}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="اختر المنتج" />
                    </SelectTrigger>
                    <SelectContent>
                      {products.map((product) => (
                        <SelectItem key={product.product_id} value={product.product_id.toString()}>
                          {product.type} - {product.brand} {product.size && `(${product.size})`} 
                          - متوفر: {product.current_quantity}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  {selectedProduct && (
                    <p className="text-sm text-gray-600 mt-1">
                      الكمية المتوفرة: {selectedProduct.current_quantity}
                    </p>
                  )}
                </div>
                
                <div>
                  <Label htmlFor="customer_name">اسم العميل *</Label>
                  <Input
                    id="customer_name"
                    value={formData.customer_name}
                    onChange={(e) => setFormData({...formData, customer_name: e.target.value})}
                    required
                  />
                </div>

                <div>
                  <Label htmlFor="quantity">الكمية *</Label>
                  <Input
                    id="quantity"
                    type="number"
                    min="1"
                    max={selectedProduct?.current_quantity || 999}
                    value={formData.quantity}
                    onChange={(e) => setFormData({...formData, quantity: e.target.value})}
                    required
                  />
                </div>

                <div>
                  <Label htmlFor="price">السعر الإجمالي *</Label>
                  <Input
                    id="price"
                    type="number"
                    step="0.01"
                    min="0"
                    value={formData.price}
                    onChange={(e) => setFormData({...formData, price: e.target.value})}
                    required
                  />
                  {selectedProduct?.selling_price && formData.quantity && (
                    <p className="text-sm text-gray-600 mt-1">
                      السعر المقترح: {(selectedProduct.selling_price * parseInt(formData.quantity || 0)).toFixed(2)} ر.س
                    </p>
                  )}
                </div>

                <div>
                  <Label htmlFor="date">التاريخ *</Label>
                  <Input
                    id="date"
                    type="date"
                    value={formData.date}
                    onChange={(e) => setFormData({...formData, date: e.target.value})}
                    required
                  />
                </div>
              </div>

              <div>
                <Label htmlFor="notes">ملاحظات</Label>
                <Textarea
                  id="notes"
                  value={formData.notes}
                  onChange={(e) => setFormData({...formData, notes: e.target.value})}
                  rows={3}
                />
              </div>

              <div className="flex gap-2">
                <Button type="submit">حفظ الصادر</Button>
                <Button type="button" variant="outline" onClick={resetForm}>
                  إلغاء
                </Button>
              </div>
            </form>
          </CardContent>
        </Card>
      )}

      {/* Outgoing Items List */}
      <div className="space-y-4">
        {outgoingItems.map((item) => (
          <Card key={item.outgoing_id} className="hover:shadow-lg transition-shadow">
            <CardContent className="p-6">
              <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                <div className="md:col-span-2">
                  <div className="flex items-center gap-3 mb-2">
                    <TrendingDown className="h-5 w-5 text-red-600" />
                    <h3 className="font-semibold text-lg">
                      {item.product?.type} - {item.product?.brand}
                    </h3>
                  </div>
                  {item.product?.size && (
                    <p className="text-sm text-gray-600 mb-1">
                      المقاس: {item.product.size}
                    </p>
                  )}
                  <div className="flex items-center gap-2 text-sm text-gray-600">
                    <User className="h-4 w-4" />
                    <span>العميل: {item.customer_name}</span>
                  </div>
                </div>

                <div className="space-y-2">
                  <div className="flex justify-between">
                    <span className="text-sm text-gray-600">الكمية:</span>
                    <span className="font-medium">{item.quantity}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-sm text-gray-600">السعر الإجمالي:</span>
                    <span className="font-medium">{item.price} ر.س</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-sm text-gray-600">سعر الوحدة:</span>
                    <span className="font-medium">{item.unit_price?.toFixed(2)} ر.س</span>
                  </div>
                  {item.total_profit > 0 && (
                    <div className="flex justify-between">
                      <span className="text-sm text-gray-600">الربح:</span>
                      <Badge variant="secondary" className="text-green-700 bg-green-100">
                        <DollarSign className="h-3 w-3 ml-1" />
                        {item.total_profit.toFixed(2)} ر.س
                      </Badge>
                    </div>
                  )}
                </div>

                <div className="space-y-2">
                  <div className="flex items-center gap-2 text-sm text-gray-600">
                    <Calendar className="h-4 w-4" />
                    <span>{formatDate(item.date)}</span>
                  </div>
                  {item.notes && (
                    <div className="text-sm text-gray-600">
                      <strong>ملاحظات:</strong> {item.notes}
                    </div>
                  )}
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => generateInvoice(item.outgoing_id)}
                    className="flex items-center gap-2 mt-2"
                  >
                    <FileText className="h-4 w-4" />
                    طباعة فاتورة
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {outgoingItems.length === 0 && !loading && (
        <Card>
          <CardContent className="text-center py-12">
            <TrendingDown className="h-12 w-12 text-gray-400 mx-auto mb-4" />
            <p className="text-lg text-gray-600 mb-2">لا توجد صادرات</p>
            <p className="text-sm text-gray-500">ابدأ بتسجيل صادر جديد</p>
          </CardContent>
        </Card>
      )}

      {error && (
        <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded">
          {error}
        </div>
      )}
    </div>
  )
}

export default Outgoing

