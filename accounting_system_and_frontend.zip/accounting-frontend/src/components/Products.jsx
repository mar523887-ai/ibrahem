import { useState, useEffect } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Badge } from '@/components/ui/badge'
import { 
  Plus, 
  Search, 
  Edit, 
  Trash2, 
  Package,
  AlertTriangle
} from 'lucide-react'

const API_BASE = '/api'

function Products() {
  const [products, setProducts] = useState([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState(null)
  const [searchTerm, setSearchTerm] = useState('')
  const [showAddForm, setShowAddForm] = useState(false)
  const [editingProduct, setEditingProduct] = useState(null)
  const [formData, setFormData] = useState({
    type: '',
    size: '',
    brand: '',
    current_quantity: 0,
    import_price: '',
    selling_price: ''
  })

  useEffect(() => {
    fetchProducts()
  }, [])

  const fetchProducts = async () => {
    try {
      setLoading(true)
      const response = await fetch(`${API_BASE}/products`)
      if (!response.ok) {
        throw new Error('فشل في تحميل المنتجات')
      }
      const data = await response.json()
      setProducts(data)
    } catch (err) {
      setError(err.message)
    } finally {
      setLoading(false)
    }
  }

  const handleSubmit = async (e) => {
    e.preventDefault()
    try {
      const url = editingProduct 
        ? `${API_BASE}/products/${editingProduct.product_id}`
        : `${API_BASE}/products`
      
      const method = editingProduct ? 'PUT' : 'POST'
      
      const response = await fetch(url, {
        method,
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(formData),
      })

      if (!response.ok) {
        throw new Error('فشل في حفظ المنتج')
      }

      await fetchProducts()
      resetForm()
    } catch (err) {
      setError(err.message)
    }
  }

  const handleDelete = async (productId) => {
    if (!confirm('هل أنت متأكد من حذف هذا المنتج؟')) {
      return
    }

    try {
      const response = await fetch(`${API_BASE}/products/${productId}`, {
        method: 'DELETE',
      })

      if (!response.ok) {
        throw new Error('فشل في حذف المنتج')
      }

      await fetchProducts()
    } catch (err) {
      setError(err.message)
    }
  }

  const resetForm = () => {
    setFormData({
      type: '',
      size: '',
      brand: '',
      current_quantity: 0,
      import_price: '',
      selling_price: ''
    })
    setShowAddForm(false)
    setEditingProduct(null)
  }

  const startEdit = (product) => {
    setFormData({
      type: product.type,
      size: product.size || '',
      brand: product.brand || '',
      current_quantity: product.current_quantity,
      import_price: product.import_price || '',
      selling_price: product.selling_price || ''
    })
    setEditingProduct(product)
    setShowAddForm(true)
  }

  const filteredProducts = products.filter(product =>
    product.type.toLowerCase().includes(searchTerm.toLowerCase()) ||
    (product.brand && product.brand.toLowerCase().includes(searchTerm.toLowerCase())) ||
    (product.size && product.size.toLowerCase().includes(searchTerm.toLowerCase()))
  )

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="text-lg text-gray-600">جاري تحميل المنتجات...</div>
      </div>
    )
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <h2 className="text-2xl font-bold text-gray-800">إدارة المنتجات</h2>
        <Button 
          onClick={() => setShowAddForm(true)}
          className="flex items-center gap-2"
        >
          <Plus className="h-4 w-4" />
          إضافة منتج جديد
        </Button>
      </div>

      {/* Search */}
      <Card>
        <CardContent className="p-4">
          <div className="relative">
            <Search className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
            <Input
              placeholder="البحث في المنتجات..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pr-10"
            />
          </div>
        </CardContent>
      </Card>

      {/* Add/Edit Form */}
      {showAddForm && (
        <Card>
          <CardHeader>
            <CardTitle>
              {editingProduct ? 'تعديل المنتج' : 'إضافة منتج جديد'}
            </CardTitle>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="type">نوع المنتج *</Label>
                  <Input
                    id="type"
                    value={formData.type}
                    onChange={(e) => setFormData({...formData, type: e.target.value})}
                    required
                  />
                </div>
                <div>
                  <Label htmlFor="brand">الماركة</Label>
                  <Input
                    id="brand"
                    value={formData.brand}
                    onChange={(e) => setFormData({...formData, brand: e.target.value})}
                  />
                </div>
                <div>
                  <Label htmlFor="size">المقاس</Label>
                  <Input
                    id="size"
                    value={formData.size}
                    onChange={(e) => setFormData({...formData, size: e.target.value})}
                  />
                </div>
                <div>
                  <Label htmlFor="current_quantity">الكمية الحالية</Label>
                  <Input
                    id="current_quantity"
                    type="number"
                    value={formData.current_quantity}
                    onChange={(e) => setFormData({...formData, current_quantity: parseInt(e.target.value) || 0})}
                  />
                </div>
                <div>
                  <Label htmlFor="import_price">سعر الاستيراد</Label>
                  <Input
                    id="import_price"
                    type="number"
                    step="0.01"
                    value={formData.import_price}
                    onChange={(e) => setFormData({...formData, import_price: e.target.value})}
                  />
                </div>
                <div>
                  <Label htmlFor="selling_price">سعر البيع</Label>
                  <Input
                    id="selling_price"
                    type="number"
                    step="0.01"
                    value={formData.selling_price}
                    onChange={(e) => setFormData({...formData, selling_price: e.target.value})}
                  />
                </div>
              </div>
              <div className="flex gap-2">
                <Button type="submit">
                  {editingProduct ? 'تحديث' : 'إضافة'}
                </Button>
                <Button type="button" variant="outline" onClick={resetForm}>
                  إلغاء
                </Button>
              </div>
            </form>
          </CardContent>
        </Card>
      )}

      {/* Products List */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredProducts.map((product) => (
          <Card key={product.product_id} className="hover:shadow-lg transition-shadow">
            <CardHeader className="pb-3">
              <div className="flex items-start justify-between">
                <div>
                  <CardTitle className="text-lg">{product.type}</CardTitle>
                  {product.brand && (
                    <p className="text-sm text-gray-600 mt-1">{product.brand}</p>
                  )}
                </div>
                <div className="flex gap-1">
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => startEdit(product)}
                  >
                    <Edit className="h-4 w-4" />
                  </Button>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => handleDelete(product.product_id)}
                  >
                    <Trash2 className="h-4 w-4" />
                  </Button>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {product.size && (
                  <div className="flex justify-between">
                    <span className="text-sm text-gray-600">المقاس:</span>
                    <span className="text-sm font-medium">{product.size}</span>
                  </div>
                )}
                
                <div className="flex justify-between items-center">
                  <span className="text-sm text-gray-600">الكمية:</span>
                  <div className="flex items-center gap-2">
                    <span className="text-sm font-medium">{product.current_quantity}</span>
                    {product.current_quantity <= 10 && (
                      <Badge variant="destructive" className="text-xs">
                        <AlertTriangle className="h-3 w-3 ml-1" />
                        مخزون منخفض
                      </Badge>
                    )}
                  </div>
                </div>

                {product.import_price && (
                  <div className="flex justify-between">
                    <span className="text-sm text-gray-600">سعر الاستيراد:</span>
                    <span className="text-sm font-medium">{product.import_price} ر.س</span>
                  </div>
                )}

                {product.selling_price && (
                  <div className="flex justify-between">
                    <span className="text-sm text-gray-600">سعر البيع:</span>
                    <span className="text-sm font-medium">{product.selling_price} ر.س</span>
                  </div>
                )}

                {product.profit_per_unit > 0 && (
                  <div className="flex justify-between">
                    <span className="text-sm text-gray-600">الربح لكل وحدة:</span>
                    <span className="text-sm font-medium text-green-600">
                      {product.profit_per_unit} ر.س
                    </span>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {filteredProducts.length === 0 && !loading && (
        <Card>
          <CardContent className="text-center py-12">
            <Package className="h-12 w-12 text-gray-400 mx-auto mb-4" />
            <p className="text-lg text-gray-600 mb-2">لا توجد منتجات</p>
            <p className="text-sm text-gray-500">
              {searchTerm ? 'لم يتم العثور على منتجات تطابق البحث' : 'ابدأ بإضافة منتج جديد'}
            </p>
          </CardContent>
        </Card>
      )}

      {error && (
        <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded">
          {error}
        </div>
      )}
    </div>
  )
}

export default Products

