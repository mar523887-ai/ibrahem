import { useState, useEffect } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { 
  Package, 
  TrendingUp, 
  TrendingDown, 
  DollarSign,
  AlertTriangle,
  Calendar
} from 'lucide-react'

const API_BASE = '/api'

function Dashboard() {
  const [dashboardData, setDashboardData] = useState(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState(null)

  useEffect(() => {
    fetchDashboardData()
  }, [])

  const fetchDashboardData = async () => {
    try {
      setLoading(true)
      const response = await fetch(`${API_BASE}/reports/dashboard`)
      if (!response.ok) {
        throw new Error('فشل في تحميل البيانات')
      }
      const data = await response.json()
      setDashboardData(data)
    } catch (err) {
      setError(err.message)
    } finally {
      setLoading(false)
    }
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="text-lg text-gray-600">جاري تحميل البيانات...</div>
      </div>
    )
  }

  if (error) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="text-lg text-red-600">خطأ: {error}</div>
      </div>
    )
  }

  const stats = [
    {
      title: 'إجمالي المنتجات',
      value: dashboardData?.inventory?.total_products || 0,
      icon: Package,
      color: 'blue'
    },
    {
      title: 'منتجات بمخزون منخفض',
      value: dashboardData?.inventory?.low_stock_products || 0,
      icon: AlertTriangle,
      color: 'red'
    },
    {
      title: 'مبيعات اليوم',
      value: `${dashboardData?.today?.revenue || 0} ر.س`,
      icon: DollarSign,
      color: 'green'
    },
    {
      title: 'ربح اليوم',
      value: `${dashboardData?.today?.profit || 0} ر.س`,
      icon: TrendingUp,
      color: 'emerald'
    }
  ]

  const monthlyStats = [
    {
      title: 'إيرادات الشهر',
      value: `${dashboardData?.this_month?.revenue || 0} ر.س`,
      subtitle: `${dashboardData?.this_month?.sales_count || 0} عملية بيع`
    },
    {
      title: 'تكلفة المشتريات',
      value: `${dashboardData?.this_month?.cost || 0} ر.س`,
      subtitle: `${dashboardData?.this_month?.purchases_count || 0} عملية شراء`
    },
    {
      title: 'صافي الربح',
      value: `${dashboardData?.this_month?.profit || 0} ر.س`,
      subtitle: 'هذا الشهر'
    }
  ]

  return (
    <div className="space-y-6">
      {/* Welcome Section */}
      <div className="bg-gradient-to-r from-blue-600 to-blue-800 text-white p-6 rounded-lg">
        <h2 className="text-2xl font-bold mb-2">مرحباً بك في نظام المحاسبة</h2>
        <p className="text-blue-100">
          تابع أداء مستودعك ومبيعاتك من خلال لوحة التحكم هذه
        </p>
      </div>

      {/* Quick Stats */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {stats.map((stat, index) => {
          const Icon = stat.icon
          return (
            <Card key={index} className="hover:shadow-lg transition-shadow">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-gray-600 mb-1">
                      {stat.title}
                    </p>
                    <p className="text-2xl font-bold text-gray-900">
                      {stat.value}
                    </p>
                  </div>
                  <div className={`p-3 rounded-full bg-${stat.color}-100`}>
                    <Icon className={`h-6 w-6 text-${stat.color}-600`} />
                  </div>
                </div>
              </CardContent>
            </Card>
          )
        })}
      </div>

      {/* Monthly Overview */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {monthlyStats.map((stat, index) => (
          <Card key={index}>
            <CardHeader className="pb-3">
              <CardTitle className="text-lg">{stat.title}</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-gray-900 mb-1">
                {stat.value}
              </div>
              <p className="text-sm text-gray-600">{stat.subtitle}</p>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Top Products */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <TrendingUp className="h-5 w-5" />
            أفضل المنتجات مبيعاً هذا الشهر
          </CardTitle>
        </CardHeader>
        <CardContent>
          {dashboardData?.top_products?.length > 0 ? (
            <div className="space-y-4">
              {dashboardData.top_products.map((product, index) => (
                <div key={index} className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                  <div className="flex items-center gap-3">
                    <Badge variant="secondary" className="w-8 h-8 rounded-full flex items-center justify-center">
                      {index + 1}
                    </Badge>
                    <div>
                      <p className="font-medium text-gray-900">
                        {product.product.type} - {product.product.brand}
                      </p>
                      <p className="text-sm text-gray-600">
                        المقاس: {product.product.size || 'غير محدد'}
                      </p>
                    </div>
                  </div>
                  <div className="text-left">
                    <p className="font-bold text-gray-900">
                      {product.total_sales} ر.س
                    </p>
                    <p className="text-sm text-gray-600">
                      {product.total_quantity} قطعة
                    </p>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="text-center py-8 text-gray-500">
              لا توجد مبيعات هذا الشهر
            </div>
          )}
        </CardContent>
      </Card>

      {/* Quick Actions */}
      <Card>
        <CardHeader>
          <CardTitle>إجراءات سريعة</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <button className="p-4 border-2 border-dashed border-gray-300 rounded-lg hover:border-blue-500 hover:bg-blue-50 transition-colors">
              <Package className="h-8 w-8 text-gray-400 mx-auto mb-2" />
              <p className="text-sm font-medium text-gray-600">إضافة منتج جديد</p>
            </button>
            <button className="p-4 border-2 border-dashed border-gray-300 rounded-lg hover:border-green-500 hover:bg-green-50 transition-colors">
              <TrendingUp className="h-8 w-8 text-gray-400 mx-auto mb-2" />
              <p className="text-sm font-medium text-gray-600">تسجيل وارد</p>
            </button>
            <button className="p-4 border-2 border-dashed border-gray-300 rounded-lg hover:border-red-500 hover:bg-red-50 transition-colors">
              <TrendingDown className="h-8 w-8 text-gray-400 mx-auto mb-2" />
              <p className="text-sm font-medium text-gray-600">تسجيل صادر</p>
            </button>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}

export default Dashboard

